#include"Students.h"
#include<vector>
#include<string>
#include<conio.h>
#include<fstream>
using namespace std;
class Admin{
	string Name;
	string id;
	string password;
public:
	int idx;
	Admin() {
		 Name="";
		 id="";
		 password="";
	} 
	Admin(string n,string i,string p) {
		Name = n;
		id = i;
		password = p;
	}
	void setName(string Dname) {
		this->Name = Dname;
	}
	string getName() {
		return Name;
	}    
	void setAdPass(string passd) {
		this->password = passd;
	}
	string getAdPass() {
		return password;
	}
	void setI(string di) {
		this->id = di;
	}
	string getI() {
		return id;
	}
	static bool AdLogin(vector<Admin>Main){
		string NotFound;
		bool found = false;
		NotFound = "ID doesn't Match Any!";
		Admin ent;
		cout << "Enter Your Id : " << endl;
		cin >> ent.id;
		bool checked = false;
		while (!checked) {
			cout << endl << "Enter your password : \t";
			char pw;
			pw = _getch();
			while (pw != '\r') {
				ent.password.push_back(pw);
				cout << '*';
				pw = _getch();
			}
			if (ent.password.size() < 8) {
				cout << "invalid length, Try again" << endl;
				checked = false;
			}
			else checked = true;			
		}
		if (checked) {
			
			for (int i = 0; i < Main.size();i++) {
				if (ent.id==Main[i].getI()&&ent.password==Main[i].getAdPass()) {
					found = true;				
					break;
				}				
			}			
		}
		return found;
	}
	static void AddStudent(vector<vector<Course>>temps) {
		Students* News = new Students();
		cout << "Enter Student Name : \n";
		string tempN;
		getline(cin, tempN);
		News->setName(tempN);
		cout << endl << "Enter grade : \n";
		int temp;
		cin >> temp;
		News->setY(temp);
		if (temp == 1) {
			cout << "Select Mandatory Courses" << endl;
			for (int i = 0; i < temps[1].size(); i++) {
				cout << temps[1][i].getNC() << endl;
			}
		}
		else if (temp == 2) {
			cout << "Select Mandatory Courses" << endl;
			for (int i = 0; i < temps[2].size(); i++) {
				cout << temps[2][i].getNC() << endl;
			}
		}
		else if (temp == 3) {
			for (int i = 0; i < temps[3].size(); i++) {
				cout << temps[3][i].getNC() << endl;
			}

		}else cout << "Enter a valid Grade, from 1 to 3" << endl;
		
		fstream addstudent("StudentDb.csv", ios::app);
		addstudent <<News->getName() << ' ' << News->getpass() << ' ' << News->getName() << ' ' << News->getName() << endl;
		system("cls");
		cout << "\nStudent Added Successfully";
		
	}
	void AddCourse() {
		Course* newcou = new Course();
		char s;
		bool m = false;
		string tempco, e;
		int max=0,g=0;
		cout << "enter Course name : ";
		getline(cin, e);
		newcou->setNC(e);
		cout << "\ninitially, this course is aimed for which year : ";
		cin >> g;
		newcou->setAc(g);
		if(g>1){
			cout << "Enter PreRequisite Course Name" << endl;
			cin >> tempco;
			newcou->preReq.push(tempco);
		}
		cout << "\nEnter 'f' for fall semester, 's' for spring semester : ";
		cin >> s;
		cout << "\nEnter Maximum Number of Students : ";
		cin >> max;
		newcou->setMax(max);
		e = toupper(e[0]);
		e.push_back(toupper(e[1]));
		newcou->setCode(e);
		int H;
		cin >> H;
		cout << "\nEnter credit Hours : ";
		newcou->setHours(H);
		newcou->setCode(newcou->getCode() + to_string(newcou->getHours()) + "H" + to_string(newcou->grade) );
		cout << "Generated Code is " << e;
		
	}
	/*stack<string> definePreqs(Course theCourse, vector<vector<Course>>temps) {
		int store = theCourse.getAc()-1;
		if (store == 1) { cout << "No Need for PreRequisites !" << endl; }
		else if(store>=2){
			for (int i = 0; temps[store].size(); i++) {
				if (theCourse.getCode()[0] == temps[store][i].getCode()[0] && theCourse.getCode()[1] == temps[store][i].getCode()[1]) {
					theCourse.preReq.push(temps[store][i].getNC());
				}
			}
		}
		return theCourse.preReq;
	}*/

};
